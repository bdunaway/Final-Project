package edu.iu.c212;
import edu.iu.c212.models.Item;
import edu.iu.c212.models.Staff;

import java.util.ArrayList;
import java.util.ListIterator;

public interface IStore {

	//reads in all inventory items
	//items are all on own line, listed as itemName, itemQuantity, itemCost, itemAisle
	ArrayList<Item> getItemsFromFile();
	
	
	//reads in all staff
	ArrayList<Staff> getStaffFromFile();
	
	//saves all items from inventory.txt
	void saveItemsFromFile();
	
	//saves all stalf from stall_availability_IN.txt
	void saveStaffFromFile();
	
	//interprets user commands
	void takeAction();
	
	
}
