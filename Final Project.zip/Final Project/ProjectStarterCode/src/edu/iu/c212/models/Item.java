package edu.iu.c212.models;

public class Item {
    private String name;
    private double price;
    private int quanity;
    private int asileNum;

    public Item(String name, double price, int quanity, int asileNum) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getQuanity() {
        return quanity;
    }

    public int getAsileNum() {
        return asileNum;
    }
}
