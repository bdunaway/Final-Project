package edu.iu.c212;

public class StaffScheduler {

    public void scheduleStaff(){}

}
