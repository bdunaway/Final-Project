package edu.iu.c212;

import edu.iu.c212.IStore;
import edu.iu.c212.models.Item;
import edu.iu.c212.models.Staff;
import edu.iu.c212.utils.FileUtils;

import java.awt.event.ItemEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;


//import DirectionPanel.DirectionListener;

import static com.sun.java.accessibility.util.AWTEventMonitor.addKeyListener;


public class Store implements IStore {





	//take action will handle all file input and call the correct methods
	//Commented out so i could run code, cntrl + / will uncomment
	public void takeAction() throws IOException {
		List<String> comms = FileUtils.readCommandsFromFile();
		for(String ele : comms){
			String[] command = ele.split(" ");
			List<String> listc = new ArrayList<>(Arrays.asList(command));
			if(listc.contains("HIRE")){
				String name = listc.get(1).replace("'", "") + " " + listc.get(2).replace("'", "");
				int age = Integer.parseInt(listc.get(3));
			}
			if(listc.contains("FIRE")){
				String name = listc.get(1).replace("'", "") + " " + listc.get(2).replace("'", "");
				FIRE(name);
			}
			if(listc.contains("PROMOTE")){
				String name = listc.get(1).replace("'", "") + " " + listc.get(2).replace("'", "");
				String role = listc.get(3);
				PROMOTE(name, role);
			}
			if(listc.contains("SCHEDULE")){
				StaffScheduler.scheduleStaff();
			}

		}

	}




	@Override
	public ArrayList<Item> getItemsFromFile() {
		return null;
	}

	@Override
	public List<Staff> getStaffFromFile() throws IOException {
		return FileUtils.readStaffFromFile();
	}

	@Override
	public void saveItemsFromFile()  {

	}

	@Override
	public void saveStaffFromFile() throws IOException { //Dont know what this method should do, duplicate method
		FileUtils.readStaffFromFile();
	}

	//This method will call get staff and a get a list of staff, add the new member to the list, then call staffwriter.
	public void HIRE(String name, int age, String role, String availability) throws IOException {
		List<Staff> staff;
		staff = getStaffFromFile();
		staff.add(new Staff(name, age, role, availability));
		FileUtils.writeStaffToFile(staff);
		FileUtils.writeLineToOutputFile(name + " was hired.");
	}

	public void FIRE(String staffname) throws IOException {
		List<Staff> staff;
		staff = getStaffFromFile();
		boolean found = false;

		for(Staff element : staff){
			//The writeup insinuates to check the file for all the employees names,
			//but the array list is always current with the files staff, so i only
			//check the array list
			if(element.getFullName().equals(staffname)){
				found = true;
				staff.remove(element);
				FileUtils.writeStaffToFile(staff);
				FileUtils.writeLineToOutputFile(staffname + " was fired.");
			}
			else if(found){
				break;
			}
		}
		if(!found){
			FileUtils.writeLineToOutputFile("ERROR: " + staffname + " cannot be found.");
		}
	}

	public void PROMOTE(String name, String role) throws IOException {
		List<Staff> staff;
		staff = getStaffFromFile();
		//Searching for staff member in object List, then
		//changing their role. Then updating file.
		//This assumes the input will be a character like 'M' or 'G'
		for(Staff element : staff){
			if(element.getFullName().equals(name)){
				element.setRole(roleHelper(role));
				FileUtils.writeStaffToFile(staff);
				FileUtils.writeLineToOutputFile(name + " was promoted to " + roleHelper(role) + ".");

			}
		}
	}

	public String roleHelper(String role){

		return switch (role) {
			case "G" -> "Gardening Expert";
			case "C" -> "Cashier";
			case "M" -> "Manager";
			default -> null;
		};
	}

	public void ADD(String name, double price, int quantity, int aisle) throws IOException{
		List<Item> itemArr;
		itemArr = getItemsFromFile();

		Item item = new Item(name,price,quantity,aisle);

		itemArr.add(item);
		FileUtils.writeInventoryToFile(itemArr);
		FileUtils.writeLineToOutputFile(item.getName() + " was added to inventory");
	}

	public void COST(String itemName) throws IOException {
		ArrayList<Item> itemArr= new ArrayList<>();
		itemArr = getItemsFromFile();
		for(Item x : itemArr) {
			if(x.getName().equals(itemName)) {
				String outputString = x.getName() + ":$" + x.getPrice();
				FileUtils.writeLineToOutputFile(outputString);
			}
		}

	}

	public void QUANTITY(String itemName) throws IOException {
		ArrayList<Item> itemArr = new ArrayList<>();
		itemArr = getItemsFromFile();
		for(Item x : itemArr) {
			if(x.getName().equals(itemName)) {
				FileUtils.writeLineToOutputFile(""+x.getQuantity());
			}
		}
	}

	public void FIND(String itemName) throws IOException {
		ArrayList<Item> itemArr = new ArrayList<>();
		itemArr = getItemsFromFile();
		for(Item x : itemArr) {
			if(x.getName().equals(itemName)) {
				FileUtils.writeLineToOutputFile("Performing store lookup for " + x.getName());
				//THIS IS WHERE STORE MAP SHOULD APPEAR

			}
			else {
				FileUtils.writeLineToOutputFile("ERROR: " + x.getName() + " could not be found");
			}
		}
	}

	public void SELL(String itemName, int quantity) throws IOException {
		ArrayList<Item> itemArr = new ArrayList<>();
		itemArr = getItemsFromFile();
		for(int i = 0; i < itemArr.size(); i++) {
			if(itemArr.get(i).getName().equals(itemName) && itemArr.get(i).getQuantity()>= quantity) {
				FileUtils.writeLineToOutputFile(quantity + " " + itemArr.get(i).getName() + " was sold");
				itemArr.get(i).setQuantity(itemArr.get(i).getQuantity()-quantity);
			}
			else {
				FileUtils.writeLineToOutputFile("Error: " + itemArr.get(i) + " could not be sold");
			}
		}
	}

	    public static void main(String[] args) throws IOException {
        	Store st = new Store();
			st.takeAction();

        }
    }



