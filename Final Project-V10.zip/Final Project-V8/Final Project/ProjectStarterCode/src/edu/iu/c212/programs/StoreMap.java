package edu.iu.c212.programs;

import javax.swing.*;
import java.awt.*;

public class StoreMap extends JComponent {
    private final int aisleNum;
    public StoreMap(int aisleNumberToHighlight) {
        this.aisleNum = aisleNumberToHighlight;
    }

    public void paintComponent(Graphics g) {
        // Drawing the map
        // No need to touch the code in this section of the method
        // Set StoreMapDisplay.WIDTH to 700 and StoreMapDisplay.HEIGHT to 500 for this to display properly!
        int canvasWidth = StoreMapDisplay.WIDTH - 10;
        int canvasHeight = StoreMapDisplay.HEIGHT - 37;
        int aisleWidth = 200;
        int aisleHeight = 40;
        // draw the map
        // perimeter walls
        g.setColor(Color.GRAY);
        g.fillRect(0, 0, canvasWidth, 10); // north
        g.fillRect(0, canvasHeight-10, canvasWidth, 10); // south
        g.fillRect(0, 0, 10, canvasHeight-10); // west
        g.fillRect(canvasWidth-13, 0, 10, canvasHeight-10); // east
        // draw gardening section walls
        g.fillRect(450, 0, 10, canvasHeight/2); // west
        g.fillRect(450, canvasHeight/2-10, canvasHeight/2, 10);
        // draw shelves
        g.setColor(Color.BLUE);
        for (int i = 0; i < 7; i++) {
            g.fillRect(30, 30 + 60 * i, aisleWidth, aisleHeight);
            if (i > 3) g.fillRect(450, 30 + 60 * i, aisleWidth, aisleHeight);
        }
        // draw planter boxes in gardening section
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                g.fillRect(490 + 60 * i, 30 + 60 * j, 40, 40);
            }
        }
        // draw aisle numbers
        // shelves
        g.setColor(Color.BLACK);
        for (int i = 0; i < 12; i++) {
            if (i < 8) {
                g.drawString("Aisle " + (i+1), 110, 25 + 60 * i);
            } else {
                g.drawString("Aisle " + (i+1), 530, 25 + 60 * (i-4));
            }
        }
        // planter boxes
        g.setColor(Color.WHITE);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                g.drawString("A " + (12 + (i+1) + 3 * j), 500 + i * 60, 60 + 60 * j);
            }

        }



        // TODO: draw the box appropriately around the aisle. You'll need to define these boundaries yourself for each one!
        g.setColor(Color.GREEN);
        //in final program we will recieve this from an item object that is passed in
        int itemAisle = 21;
        //main aisles
        if (itemAisle == 1){
            g.drawRect(25, 25, 225, 50);
        }
        else if(itemAisle ==2){
            g.drawRect(25, 25+60*(itemAisle-1),225,50);
        }
        else if(itemAisle ==3){
            g.drawRect(25, 25+60*(itemAisle-1),225,50);
        }
        else if(itemAisle ==4){
            g.drawRect(25, 25+60*(itemAisle-1),225,50);
        }
        else if(itemAisle ==5){
            g.drawRect(25, 25+60*(itemAisle-1),225,50);
        }
        else if(itemAisle ==6){
            g.drawRect(25, 25+60*(itemAisle-1),225,50);
        }
        else if(itemAisle ==7){
            g.drawRect(25, 25+60*(itemAisle-1),225,50);
        }
        else if(itemAisle ==8){
            g.drawRect(25, 25+60*(itemAisle-1),225,50);
        }

        else if(itemAisle == 9){
            g.drawRect(435, 265, 225, 50);
        }
        else if(itemAisle == 10){
            g.drawRect(435, 325, 225, 50);
        }
        else if (itemAisle == 11){
            g.drawRect(435, 325 + (325-265),225,50);
        }
        else if (itemAisle == 12){
            g.drawRect(435, 325 + (325-265),225,50);
        }


        //planter boxes
        else if (itemAisle == 13){
            g.drawRect(485, 25,50,50);
        }
        else if (itemAisle == 14){
            g.drawRect(485+60, 25,50,50);
        }
        else if (itemAisle == 15){
            g.drawRect(485+60+60, 25,50,50);
        }
        else if (itemAisle == 16){
            g.drawRect(485, 85,50,50);
        }
        else if (itemAisle == 17){
            g.drawRect(485+60, 85,50,50);
        }
        else if (itemAisle == 18){
            g.drawRect(485+60+60, 85,50,50);
        }
        else if (itemAisle == 19){
            g.drawRect(485, 85+60,50,50);
        }
        else if (itemAisle == 20){
            g.drawRect(485+60, 85+60,50,50);
        }
        else if (itemAisle == 21){
            g.drawRect(485+120, 85+60,50,50);
        }


        }

}
