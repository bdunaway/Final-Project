package edu.iu.c212.programs;
import edu.iu.c212.models.Item;
import edu.iu.c212.utils.FileUtils;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.List;

public class StoreMapDisplay {

    public static final int WIDTH = 700;
    public static final int HEIGHT = 500;

    public static void display(Item product) throws IOException {
        JFrame fr = new JFrame("High's Hardware Product Lookup: <product name>");
        fr.setPreferredSize(new Dimension(700, 500));
        StoreMap store = new StoreMap(product.getAsileNum());
        fr.add(store);
        fr.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        fr.pack();
        fr.setVisible(true);

    }
}



