import java.util.ListIterator;

public interface IStore {

	//reads in all inventory items
	//items are all on own line, listed as itemName, itemQuantity, itemCost, itemAisle
	List<Item> getItemsFromFile();
	
	
	//reads in all staff
	List<Staff> getStaffFromFile();
	
	//saves all items from inventory.txt
	void saveItemsFromFile();
	
	//saves all stalf from stall_availability_IN.txt
	void saveStaffFromFile();
	
	//interprets user commands
	void takeAction();
	
	
}
