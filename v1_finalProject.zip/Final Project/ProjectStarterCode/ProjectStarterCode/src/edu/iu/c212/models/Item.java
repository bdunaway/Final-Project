
public class Item {
	
	//class vars
	private String name;
	private double price;
	private int quantity;
	private int aisleNum;
	
	//constructor
	public Item(String name, double price, int quantity, int aisleNum) {
		
		//initialize variables
		this.name = name;
		this.price = price;
		this.quantity = quantity;
		this.aisleNum = aisleNum;
	}
	
	//getters
	public String getName() {
		return name;
	}
	
	public double getPrice() {
		return price;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public int getAisle() {
		return aisleNum;
	}
}
