import java.awt.event.ItemEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;

public class Store implements IStore{


	
	
	
	//take action will handle all file input and call the correct methods
	void takeAction(String inputFile) {
		
		//creates new file from path provided
		File inputFile = new File(inputFile);
		//scanner that can read file
		Scanner in = new Scanner(inputFile);
		
		//as long as file has another line, keep processing commands
		while(in.hasNextLine()) {
			
			//use "next" instead of nextLine because 
			//we need to process the individual command, then get the info
			String userCommand = in.next();
			
			//if user wants to add new item
			if(userCommand.equals("ADD")) {
				//all params needed to add an item
				//THIS WILL NOT WORK FOR MUTLI WORD ITEMS- NEED TO FIX
				String itemName = in.next();
				String itemCost = in.next();
				String itemQuantity = in.next();
				String itemAisle = in.next();
				
				addItem(itemName, itemCost, itemQuantity, itemAisle);
			}
		}
		
	}
	
	//add item to output file
	public static void addItem(String itemName, String itemCost, String itemQuantity, String itemAisle) {
		//convert itemQuantity and itemAisle to ints
		int itemQuantity = Integer.parseInt(itemQuantity);
		int itemAisle = Integer.parseInt(itemAisle);
		
		//do we need to declare a new item?
		//Item newItem = new Item(itemName, itemCost, itemQuantity, itemAisle);
		
		//creates printwriter that wont delete old info as it writes 
		//MAKE SURE inventory.txt IS CORRECT FILE PATH
		PrintWriter outInventory = new PrintWriter(new FileWriter("inventory.txt", true));
		//writes item info to inventory.txt
		outInventory.write("'"+itemName+"',"+itemCost+","+itemQuantity+","+itemAisle);
		
		//creates printwriter for outputfile
		PrintWriter out = new PrintWriter(new FileWriter("output.txt", true));
		out.write(itemName + " was added to inventory");
		
		
		
		
		outInventory.close();
		out.close();
	}
			
	
	
}
