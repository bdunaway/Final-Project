package edu.iu.c212;

import edu.iu.c212.IStore;
import edu.iu.c212.models.Item;
import edu.iu.c212.models.Staff;
import edu.iu.c212.utils.FileUtils;

import java.awt.event.ItemEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Store implements IStore {


	
	
	
	//take action will handle all file input and call the correct methods
	//Commented out so i could run code, cntrl + / will uncomment
	public void takeAction() {

//		//* Hardcode the filename instead of using pass a param *
//
//		//creates new file from path provided
//		File inputFile = new File(inputFile);
//		//scanner that can read file
//		Scanner in = new Scanner(inputFile);
//
//		//as long as file has another line, keep processing commands
//		while(in.hasNextLine()) {
//
//			//use "next" instead of nextLine because
//			//we need to process the individual command, then get the info
//			String userCommand = in.next();
//
//			//if user wants to add new item
//			if(userCommand.equals("ADD")) {
//				//all params needed to add an item
//				//THIS WILL NOT WORK FOR MUTLI WORD ITEMS- NEED TO FIX
//				String itemName = in.next();
//				String itemCost = in.next();
//				String itemQuantity = in.next();
//				String itemAisle = in.next();
//
//				addItem(itemName, itemCost, itemQuantity, itemAisle);
//			}
//		}

	}
	
	//add item to output file
	public static void addItem(String itemName, String itemCost, String itemQuantity, String itemAisle) {
//		//convert itemQuantity and itemAisle to ints
//		int itemQuantity = Integer.parseInt(itemQuantity);
//		int itemAisle = Integer.parseInt(itemAisle);
//
//		//do we need to declare a new item?
//		//Item newItem = new Item(itemName, itemCost, itemQuantity, itemAisle);
//
//		//creates printwriter that wont delete old info as it writes
//		//MAKE SURE inventory.txt IS CORRECT FILE PATH
//		PrintWriter outInventory = new PrintWriter(new FileWriter("inventory.txt", true));
//		//writes item info to inventory.txt
//		outInventory.write("'"+itemName+"',"+itemCost+","+itemQuantity+","+itemAisle);
//
//		//creates printwriter for outputfile
//		PrintWriter out = new PrintWriter(new FileWriter("output.txt", true));
//		out.write(itemName + " was added to inventory");
//
//
//
//
//		outInventory.close();
//		out.close();
	}


	@Override
	public ArrayList<Item> getItemsFromFile() {
		return null;
	}

	@Override
	public List<Staff> getStaffFromFile() throws IOException {
		return FileUtils.readStaffFromFile();
	}

	@Override
	public void saveItemsFromFile() {

	}

	@Override
	public void saveStaffFromFile() throws IOException { //Dont know what this method should do, duplicate method
		FileUtils.readStaffFromFile();
	}

	//This method will call get staff and a get a list of staff, add the new member to the list, then call staffwriter.
	public void HIRE(String name, int age, String role, String availability) throws IOException {
		List<Staff> staff;
		staff = getStaffFromFile();
		staff.add(new Staff(name, age, role, availability));
		FileUtils.writeStaffToFile(staff);
		FileUtils.writeLineToOutputFile(name + " was hired.");
	}

	public void FIRE(String staffname) throws IOException {
		List<Staff> staff;
		staff = getStaffFromFile();
		boolean found = false;

		for(Staff element : staff){
			//The writeup insinuates to check the file for all the employees names,
			//but the array list is always current with the files staff, so i only
			//check the array list
			if(element.getFullName().equals(staffname)){
				found = true;
				staff.remove(element);
				FileUtils.writeStaffToFile(staff);
				FileUtils.writeLineToOutputFile(staffname + " was fired.");
			}
			else if(found){
				break;
			}
		}
		if(!found){
			FileUtils.writeLineToOutputFile("ERROR: " + staffname + " cannot be found.");
		}
	}

	public void PROMOTE(String name, String role) throws IOException {
		List<Staff> staff;
		staff = getStaffFromFile();
		//Searching for staff member in object List, then
		//changing their role. Then updating file.
		//This assumes the input will be a character like 'M' or 'G'
		for(Staff element : staff){
			if(element.getFullName().equals(name)){
				element.setRole(roleHelper(role));
				FileUtils.writeStaffToFile(staff);
				FileUtils.writeLineToOutputFile(name + " was promoted to " + roleHelper(role) + ".");

			}
		}
	}

	public String roleHelper(String role){

		return switch (role) {
			case "G" -> "Gardening Expert";
			case "C" -> "Cashier";
			case "M" -> "Manager";
			default -> null;
		};
	}



}
