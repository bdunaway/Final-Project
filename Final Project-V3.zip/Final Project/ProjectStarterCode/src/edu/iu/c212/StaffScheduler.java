package edu.iu.c212;

import edu.iu.c212.models.Staff;
import edu.iu.c212.utils.FileUtils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StaffScheduler {
    private static File staffAvailabilityFile = new File("ProjectStarterCode/src/edu/iu/c212/resources/staff_availability_IN.txt");
    private static File shiftSchedulesFile = new File("ProjectStarterCode/src/edu/iu/c212/resources/shift_schedules_IN.txt");
    private static File storeScheduleFile = new File("ProjectStarterCode/src/edu/iu/c212/resources/store_schedule_OUT.txt");

    public static List<Float> scheduleStaff() throws IOException {
        List<String> strs= new ArrayList<>();
        List<Float> nums = new ArrayList<>();

        Scanner l = new Scanner(Path.of(shiftSchedulesFile.toURI()));

        //Making array list of element
        while(l.hasNext()) {
            String input = l.next();
            strs.add(input);
        }

        float total = 0;
        int count = 0;
        for(int i = 0 ; i < strs.size() ; i = i + 3){
            nums.add((float) ((Float.parseFloat(strs.get(i + 2)) - Float.parseFloat(strs.get(i + 1))) / 100));
            total = total + nums.get(count);
            count++;
        }
        System.out.println(total);
        return nums;
    }

        public static void main(String[] args) throws IOException {
        List<Float> st = StaffScheduler.scheduleStaff();
        System.out.println(st);
    }


}
