package edu.iu.c212;

import edu.iu.c212.models.Staff;
import edu.iu.c212.utils.FileUtils;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.nio.file.Path;
import java.util.*;

public class StaffScheduler {
    private static File staffAvailabilityFile = new File("ProjectStarterCode/src/edu/iu/c212/resources/staff_availability_IN.txt");
    private static File shiftSchedulesFile = new File("ProjectStarterCode/src/edu/iu/c212/resources/shift_schedules_IN.txt");
    private static File storeScheduleFile = new File("ProjectStarterCode/src/edu/iu/c212/resources/store_schedule_OUT.txt");

    public static List<Double> scheduleStaff() throws IOException {
        List<String> strs= new ArrayList<>();
        List<Double> nums = new ArrayList<>();

        Scanner l = new Scanner(Path.of(shiftSchedulesFile.toURI()));

        //Making array list of element
        while(l.hasNext()) {
            String input = l.next();
            strs.add(input);
        }

        double total = 0;
        int count = 0;
        for(int i = 0 ; i < strs.size() ; i = i + 3){
            nums.add((double) ((Double.parseDouble(strs.get(i + 2)) - Double.parseDouble(strs.get(i + 1))) / 100));
            total = total + nums.get(count);
            count++;
        }

        //creates array that measures how many hours each has already worked

        //String, Double, String correlate to Name, hours worked
        List<Double> hoursWorked = new ArrayList<Double>();
        List<Staff> staffArr = new ArrayList<>();
        staffArr = FileUtils.readStaffFromFile();

        for (int i = 0; i < staffArr.size();i++) {
            hoursWorked.add(0.0);
        }

        String[] daysOfWeek = {"M","T","W","TR","F","SAT","SUN"};
        List<String> outputList = new ArrayList<>();
        //this outside for loop is for checking each day of the week
        for(int i = 0; i < daysOfWeek.length; i++){
            //see who has worked the least
            double minHoursWorked = 1000;

            //for loop runs through all employees
            for(int j = 0; j < staffArr.size();j++){

                //seeing whos worked the fewest hours so far
                String[] available = staffArr.get(j).getAvailability().split("\\.");
                if(available[i].equals(daysOfWeek[i]) && hoursWorked.get(j) < minHoursWorked){
                    minHoursWorked = hoursWorked.get(j);
                }
                //need seperate if statement so that too many emps dont end up being stored on same day
                if(hoursWorked.get(j)<=minHoursWorked){
                    outputList.add(daysOfWeek[i] + "(" + staffArr.get(j).getFullName() + ")");

                    hoursWorked.set(j, hoursWorked.get(j) + nums.get(i));
                    break;
                }

            }
        }

        System.out.println(total);
        System.out.println(outputList.toString());
        return nums;
    }

    public static void main(String[] args) throws IOException {
        List<Double> st = StaffScheduler.scheduleStaff();
        System.out.println(st);
    }


}
